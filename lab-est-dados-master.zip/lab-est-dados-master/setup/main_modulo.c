// busca o ".h" no diretorio corrente
// antes de buscar no diretório de headers do sistema
#include "modulo.h"

int main(void){
    funcao_util(55);
    return 0;
}