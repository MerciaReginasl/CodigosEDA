// arquivo com protótipos + implementação
#include "modulo.h"
#include <stdio.h>

void funcao_util(int a){
    printf("a=%d\n", a);
}