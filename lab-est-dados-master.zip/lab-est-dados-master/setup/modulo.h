// arquivo de cabeçalho do módulo
// contém os protótipos das funções

void funcao_util(int a);